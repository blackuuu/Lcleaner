# Lcleaner

Clearing league logs & traces to avoid bans.

UC on top.
