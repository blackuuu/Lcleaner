#pragma once

namespace files
{
	void remove( std::filesystem::path path_log );
	void clear_logs( );
}