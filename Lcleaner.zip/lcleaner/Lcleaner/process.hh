#pragma once

namespace process
{
	void close( std::string process_name );
	void close_all(  );
}