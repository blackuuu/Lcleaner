#pragma once

#define WIN32_LEAN_AND_MEAN

#include <iostream>
#include <string>
#include <windows.h>
#include <tlhelp32.h>
#include <filesystem>
#include <thread>
#include <chrono>

#include "process.hh"
#include "files.hh"